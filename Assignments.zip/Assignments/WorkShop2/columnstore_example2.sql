USE [AdventureWorks2014];

--Table with Row Store index clustered index and Row Store   non-clustered index
CREATE TABLE   SalesOrderDetailWithRowStoreClusteredIndexAndRowStoreNonClusteredIndex(
         [SalesOrderID] [int]   NOT NULL,
         [SalesOrderDetailID] [int]   IDENTITY(1,1) NOT NULL,
         [CarrierTrackingNumber] [nvarchar](25) NULL,
         [OrderQty] [smallint]   NOT NULL,
         [ProductID] [int] NOT NULL,
         [SpecialOfferID] [int]   NOT NULL,
         [UnitPrice] [money]   NOT NULL,
         [UnitPriceDiscount] [money]   NOT NULL,
         [LineTotal] [money],
         [rowguid] [uniqueidentifier]   ROWGUIDCOL  NOT   NULL,
         [ModifiedDate] [datetime]   NOT NULL
             ) ON   [PRIMARY]
GO
 
--Table with Row Store clustered index and non-clustered Column   Store index
CREATE TABLE   SalesOrderDetailWithRowStoreClusteredIndexAndNonClusteredColumnStoreIndex(
         [SalesOrderID] [int]   NOT NULL,
         [SalesOrderDetailID] [int]   IDENTITY(1,1) NOT NULL,
         [CarrierTrackingNumber] [nvarchar](25) NULL,
         [OrderQty] [smallint]   NOT NULL,
         [ProductID] [int] NOT NULL,
         [SpecialOfferID] [int]   NOT NULL,
         [UnitPrice] [money]   NOT NULL,
         [UnitPriceDiscount] [money]   NOT NULL,
         [LineTotal] [money],
         [rowguid] [uniqueidentifier]   ROWGUIDCOL  NOT   NULL,
         [ModifiedDate] [datetime]   NOT NULL
             ) ON   [PRIMARY]
GO
 
--Table with Column Store Clustered index
CREATE TABLE SalesOrderDetailWithClusteredColumnStoreIndex(
         [SalesOrderID] [int]   NOT NULL,
         [SalesOrderDetailID] [int]   IDENTITY(1,1) NOT NULL,
         [CarrierTrackingNumber] [nvarchar](25) NULL,
         [OrderQty] [smallint]   NOT NULL,
         [ProductID] [int] NOT NULL,
         [SpecialOfferID] [int]   NOT NULL,
         [UnitPrice] [money]   NOT NULL,
         [UnitPriceDiscount] [money]   NOT NULL,
         [LineTotal] [money],
         [rowguid] [uniqueidentifier]   ROWGUIDCOL  NOT   NULL,
         [ModifiedDate] [datetime]   NOT NULL
) ON [PRIMARY]
GO

--Load data to these tables
INSERT INTO   SalesOrderDetailWithRowStoreClusteredIndexAndRowStoreNonClusteredIndex (SalesOrderID, 
CarrierTrackingNumber,     
OrderQty, ProductID,   SpecialOfferID, UnitPrice, UnitPriceDiscount,   LineTotal, rowguid,   
ModifiedDate)
SELECT   SalesOrderID, CarrierTrackingNumber,   OrderQty,   ProductID, SpecialOfferID, UnitPrice,   
UnitPriceDiscount, 
LineTotal, rowguid,   ModifiedDate FROM [AdventureWorks2014].Sales.[SalesOrderDetail]
GO 20

INSERT INTO   SalesOrderDetailWithRowStoreClusteredIndexAndNonClusteredColumnStoreIndex 
(SalesOrderID, CarrierTrackingNumber,     
OrderQty, ProductID,   SpecialOfferID, UnitPrice, UnitPriceDiscount,   LineTotal, rowguid,   
ModifiedDate)
SELECT   SalesOrderID, CarrierTrackingNumber,   OrderQty,   ProductID, SpecialOfferID, UnitPrice,   
UnitPriceDiscount, 
LineTotal, rowguid,   ModifiedDate FROM [AdventureWorks2014].Sales.[SalesOrderDetail]
GO 20

INSERT INTO SalesOrderDetailWithClusteredColumnStoreIndex (SalesOrderID, CarrierTrackingNumber,     
OrderQty, ProductID,   SpecialOfferID, UnitPrice, UnitPriceDiscount,   LineTotal, rowguid,   
ModifiedDate)
SELECT   SalesOrderID, CarrierTrackingNumber,   OrderQty,   ProductID, SpecialOfferID, UnitPrice,   
UnitPriceDiscount, 
LineTotal, rowguid,   ModifiedDate FROM [AdventureWorks2014].Sales.[SalesOrderDetail]
GO 20


--Creating Indexes - Row Store index clustered index and Row   Store non-clustered index
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
CREATE CLUSTERED INDEX   
[CIRS_SalesOrderDetailWithRowStoreClusteredIndexAndRowStoreNonClusteredIndex_SalesOrderID_SalesOrderDetailID]
ON   SalesOrderDetailWithRowStoreClusteredIndexAndRowStoreNonClusteredIndex
(SalesOrderID, SalesOrderDetailID)
GO
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
CREATE NONCLUSTERED INDEX   
[NCRS_SalesOrderDetailWithRowStoreClusteredIndexAndRowStoreNonClusteredIndex_ProductID_LineTotal]
ON   SalesOrderDetailWithRowStoreClusteredIndexAndRowStoreNonClusteredIndex
(ProductID, LineTotal)
GO


USE   AdventureWorks2014
--Creating Indexes - Row Store clustered index and non-clustered   Column Store index
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
CREATE CLUSTERED INDEX   
[CIRS_SalesOrderDetailWithRowStoreClusteredIndexAndNonClusteredColumnStoreIndex_SalesOrderID_SalesOrderDetailID]
ON   SalesOrderDetailWithRowStoreClusteredIndexAndNonClusteredColumnStoreIndex
(SalesOrderID, SalesOrderDetailID)
 GO
 SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
CREATE NONCLUSTERED COLUMNSTORE   INDEX   
[NCCS_SalesOrderDetailWithRowStoreClusteredIndexAndNonClusteredColumnStoreIndex_ProductID_LineTotal]
ON   SalesOrderDetailWithRowStoreClusteredIndexAndNonClusteredColumnStoreIndex
(ProductID, LineTotal)
GO


USE   AdventureWorks2014
--Creating Indexes - Column Store Clustered index
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO
CREATE CLUSTERED COLUMNSTORE   INDEX   [CICC_SalesOrderDetailWithClusteredColumnStoreIndex]
ON   SalesOrderDetailWithClusteredColumnStoreIndex
GO

--queries after applying columnstore index on the tables to see the difference in the execution time of the queries 
SET STATISTICS TIME ON;
SET STATISTICS IO ON;
SELECT   ProductID, SUM(LineTotal) AS 'ProductWiseSale'   FROM 
SalesOrderDetailWithRowStoreClusteredIndexAndRowStoreNonClusteredIndex
GROUP BY ProductID
ORDER BY ProductID

SELECT   ProductID, SUM(LineTotal) AS 'ProductWiseSale'   FROM 
SalesOrderDetailWithRowStoreClusteredIndexAndNonClusteredColumnStoreIndex
GROUP BY ProductID
ORDER BY ProductID

SELECT   ProductID, SUM(LineTotal) AS 'ProductWiseSale'   FROM 
SalesOrderDetailWithClusteredColumnStoreIndex
GROUP BY ProductID
ORDER BY ProductID


--columnstore index metadata
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
SELECT object_name(object_id) as ObjectName, * FROM sys.column_store_row_groups
ORDER BY object_id, row_group_id

SELECT object_name(p.object_id) AS ObjectName, C.column_id, C.segment_id , C.partition_id, 
sum(C.on_disk_size) AS on_disk_size, SUM(C.row_count) AS row_count
FROM sys.column_store_segments   C
INNER JOIN sys.partitions p
ON C.partition_id=p.partition_id
GROUP BY P.object_id, C.partition_id, C.column_id, C.segment_id 
ORDER BY P.object_id, C.partition_id, C.column_id, C.segment_id

--Insert, Update, Delete Statements
-- Create New Table
CREATE TABLE [dbo].[MySalesOrderDetail](
[SalesOrderID] [int] NOT NULL,
[SalesOrderDetailID] [int] NOT NULL,
[CarrierTrackingNumber] [nvarchar](25) NULL,
[OrderQty] [smallint] NOT NULL,
[ProductID] [int] NOT NULL,
[SpecialOfferID] [int] NOT NULL,
[UnitPrice] [money] NOT NULL,
[UnitPriceDiscount] [money] NOT NULL,
[LineTotal] [numeric](38, 6) NOT NULL,
[rowguid] [uniqueidentifier] NOT NULL,
[ModifiedDate] [datetime] NOT NULL
) ON [PRIMARY] 
GO
-- Create clustered index
CREATE CLUSTERED INDEX [CL_MySalesOrderDetail] ON [dbo].[MySalesOrderDetail] ( [SalesOrderDetailID])
GO
-- Create Sample Data Table
-- WARNING: This Query may run upto 2-10 minutes based on your systems resources
INSERT INTO [dbo].[MySalesOrderDetail] SELECT S1.*
FROM Sales.SalesOrderDetail S1
GO 100
-- Create ColumnStore Index
CREATE NONCLUSTERED COLUMNSTORE INDEX [IX_MySalesOrderDetail_ColumnStore] ON [MySalesOrderDetail] (UnitPrice, OrderQty, ProductID)
GO
-- Attempt to Update the table
UPDATE [dbo].[MySalesOrderDetail] SET OrderQty = OrderQty +1
WHERE [SalesOrderID] = 43659
GO


--For Update
-- Disable the Columnstore Index
ALTER INDEX [IX_MySalesOrderDetail_ColumnStore] ON [dbo].[MySalesOrderDetail] DISABLE
GO
-- Attempt to Update the table
UPDATE [dbo].[MySalesOrderDetail] SET OrderQty = OrderQty +1
WHERE [SalesOrderID] = 43659
GO
-- Rebuild the Columnstore Index
ALTER INDEX [IX_MySalesOrderDetail_ColumnStore] ON [dbo].[MySalesOrderDetail] REBUILD
GO


--Ignoring Columnstore index on certain queries
-- Select Table with regular Index
SELECT ProductID, SUM(UnitPrice) SumUnitPrice, AVG(UnitPrice) AvgUnitPrice,
SUM(OrderQty) SumOrderQty, AVG(OrderQty) AvgOrderQty
FROM [dbo].[MySalesOrderDetail] GROUP BY ProductID
ORDER BY ProductID
OPTION (IGNORE_NONCLUSTERED_COLUMNSTORE_INDEX)
GO